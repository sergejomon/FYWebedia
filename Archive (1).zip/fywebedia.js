let content = document.querySelector(".didomi-popup-open");
let popup = document.querySelector("#didomi-host");
if (content && popup) {
    content.classList.remove("didomi-popup-open");
    popup.remove()
}
