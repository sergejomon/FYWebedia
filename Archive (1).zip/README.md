# FYWebedia

### This firefox addon allow you to go around webedia new policy of pay-or-eat-my-cookie

To install it clone it on your PC, go to [about:debugging](about:debugging) and choose **Firefox** on the left panel. 
Then, click on *add a temporary extension*, and just choose any file from the addon directory.

This addon should work on every webedia website, please report any issue.

Enjoy !